package com.scb.scpay.kafkacontrolcenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaControlCenterApplication{

	public static void main(String[] args) {
		SpringApplication.run(KafkaControlCenterApplication.class, args);
	}

}
